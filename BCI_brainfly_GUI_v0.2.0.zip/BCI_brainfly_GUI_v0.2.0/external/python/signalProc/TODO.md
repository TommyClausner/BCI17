[] - preproc.py
	[] - WelchPSD function
	[] - valdidate it performs correctly / equivalent to matlab version
	[] - SLAP spatial filter method
[] - lr_cg logistic regression classifier
[] - cvtrain, cross-validated training regime (Q: use scikit.learn?)
[] - gennFold, intelligent generate foldings for cvtrain  (Q: use scikit.learn?)
