function [varargout]=eegViewer(varargin)
% dummy for sigViewer
[varargout{1:nargout}]=sigViewer(varargin{:});
return;