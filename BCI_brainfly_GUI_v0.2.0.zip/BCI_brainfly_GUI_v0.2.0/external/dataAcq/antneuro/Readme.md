#Ant-Neuor EEGO usage instructions:

##Linux

1) Copy the file `etc_udev_rules.d_90-eego.rules` to `/etc/udev/rules.d/90-eego.rules`
2) Copy your licience file to: `~/.eego/`  (make the `~/.eego` directory if not there)

##Windows
Not updated yet.

#Cap-Config
If you want to use a different cap-configure then, modify the config-file `buffer_bci/dataAcq/eego.cfg`

#Running

Run the scripts in `buffer_bci/dataAcq/startEego.sh` or `buffer_bci/dataAcq/startEego.bat`
