using System.Collections;

namespace FieldTrip.Buffer
	{
	public class DataDescription {
		public int nSamples;
		public int nChans;
		public int dataType;
		public int sizeBytes;
	}
}