package a.b;
public class TestFunction { 

public TestFunction(){
}

public static void HelloWorld() {
 System.out.println("Hello, World");
 }
} 
