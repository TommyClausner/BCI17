/* 
 * This will contain the implementation of the TiA server on top of the FieldTrip buffer, similar to the RDA server.
 * 
 */ 
