java -cp buffer/java/BufferClient.jar:buffer/java/SyncGenerator.jar nl.dcc.buffer_bci.SyncGenerator localhost:1972 localhost:1973
