clc
clear
close all

run([pwd filesep '..' filesep 'external' filesep 'matlab' filesep 'utilities' filesep 'initPaths.m'])

buffhost='localhost';buffport=1972;
% wait for the buffer to return valid header information
hdr=[];
while ( isempty(hdr) || ~isstruct(hdr) || (hdr.nchans==0) ) % wait for the buffer to contain valid data
  try 
    hdr=buffer('get_hdr',[],buffhost,buffport); 
  catch
    hdr=[];
    fprintf('Invalid header info... waiting.\n');
  end;
  pause(1);
end;
sendEvent('sigproc.eegviewer','start')
sigViewer([],buffport)
for i=1:20; % N.B. use a loop as safer and matlab still responds on windows...
       [devents]=buffer_newevents(buffhost,buffport,[],'sigproc.eegviewer','end',1000); % wait until finished
       drawnow;
       if ( ~isempty(devents) ) break; end;
end