import sys,os,time
import matplotlib
matplotlib.rcParams['toolbar']='None'
from psychopy import visual, core,event
import platform
from PIL import Image
import gc
gc.collect()
import pygame
pygame.init()
pygame.display.init()
import subprocess

# setup directories
main_path=os.path.dirname(os.path.abspath(__file__))+os.sep


BCI_buff_path="external"+os.sep
bufferpath = BCI_buff_path+"dataAcq"+os.sep+"buffer"+os.sep+"python"
sigProcPath = BCI_buff_path+"python"+os.sep+"signalProc"
assetpath="assets"+os.sep+"GUI_grafix"
functionspath="private"+os.sep

# add paths
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),main_path+bufferpath))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),main_path+sigProcPath))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),main_path+assetpath))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),main_path+functionspath))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),main_path+BCI_buff_path))

pathsettings=open(main_path+"config.txt","r").read().split("\n")

idx_MATLAB=int([i for i, e in enumerate([str.find(path_,'MATLABroot') for path_ in pathsettings]) if e == 0][0])
idx_Python=int([i for i, e in enumerate([str.find(path_,'Pythonroot') for path_ in pathsettings]) if e == 0][0])

# setup roots
MATLABtootpath=pathsettings[idx_MATLAB][str.find(pathsettings[idx_MATLAB],os.sep):]
Pythontootpath=pathsettings[idx_Python][str.find(pathsettings[idx_Python],os.sep):]

# setup video drivers
if platform.system() == 'Windows':
    os.environ['SDL_VIDEODRIVER'] = 'directx'
    import matlab.engine
    if 'eng' not in locals():  # start MATLAB engine if not running
        eng = matlab.engine.start_matlab()

    eng.addpath(eng.genpath(main_path))
    eng.cd(functionspath)
else:
    os.environ['SDL_VIDEODRIVER'] = 'quartz'

# switch debug / EEG mode
def debug_mode(isdebug=True):

    # run buffer components
    if isdebug:
        if platform.system() == 'Windows':
            subprocess.Popen(main_path + BCI_buff_path + 'debug_quickstart.bat &', shell=True)
            subprocess.Popen(main_path + BCI_buff_path + 'eeg_quickstart.bat &', shell=True)

            ### Add Windows start scripts here ###
            # killall java
            # EEG Viewer -> start MATLAB without nodisplay flag and run script sigViewer_wrapper.m
            # Calibration -> start MATLAB without nodisplay flag and run script calib_sig.m then start python and run calib_stim.py
            # Game -> start MATLAB WITH nodisplay flag and run script feedback_sig.m then start python and run SS_Game_BCI.py
        else:
            # find a way to kill debug scripts
            # os.system('if pgrep -x "java">/dev/null; then killall java; fi ')
            subprocess.Popen(main_path+BCI_buff_path+'debug_quickstart.sh &', shell=True)
            subprocess.Popen(main_path+BCI_buff_path+'eeg_quickstart.sh &', shell=True)
    else:
        if platform.system() == 'Windows':
            print('not implemented yet')
        else:
            # find a way to kill debug scripts
            # os.system('if pgrep -x "java">/dev/null; then killall java; fi ')
            print('not implemented yet')

class keylistener_(object):

    def __init__(self):
        self.curr_menu_idx = 2
        self.EEG_is_on = False
        self.Keyboard_is_on = True
        self.update_menu = 1
        self.done = False
        self.music=True

    def __call__(self, ev_):
        if len(ev_) > 0:
            ev_ = ev_[-1]
            if ev_ == 'up':
                self.curr_menu_idx -= 1
                update_menu = 1
            if ev_ == 'down':
                self.curr_menu_idx += 1
                update_menu = 1
            if ev_ == 'e':
                EEG_is_on = not self.EEG_is_on
                EEG_indicator.image = icons[int(EEG_is_on)]
                update_menu = 1
                debug_mode(not EEG_is_on)

            if ev_ == 'm':
                self.music = not self.music
                pygame.mixer.music.set_volume(int(self.music))

            if ev_ == 'k':
                Keyboard_is_on = not self.Keyboard_is_on
                Keyboard_indicator.image = icons[int(Keyboard_is_on) + 2]
                update_menu = 1
                scripts_[
                    -1] = 'sh ' + main_path + functionspath + 'run_game.sh ' + MATLABtootpath + ' ' + main_path + functionspath + 'feedback_sig.m ' + Pythontootpath + ' ' + main_path + functionspath + 'SS_Game_BCI.py ' + str(
                    int(not Keyboard_is_on)) + ' &'
                # scripts_[-1] ='sh ' + main_path + functionspath + 'run_game.sh ' + MATLABtootpath + ' ' + main_path + functionspath + 'feedback_sig.m ' + Pythontootpath + ' ' + main_path + functionspath + 'brainflyTest.py '+str(int(not Keyboard_is_on))+' &'

        if self.curr_menu_idx < 0:
            self.curr_menu_idx = 3

        if self.curr_menu_idx > 3:
            self.curr_menu_idx = 0

        if ev_ == 'return':

            if self.curr_menu_idx == 3:
                core.quit()
                done = True
            else:
                if self.curr_menu_idx != 0:
                    pygame.mixer.music.set_volume(0)
                if platform.system() == 'Windows':
                    if self.curr_menu_idx == 0:
                        eng.sigViewer_wrapper(nargout=0)
                    elif self.curr_menu_idx == 1:
                        eng.calib_sig(nargout=0)
                        time.sleep(5)
                        os.system(main_path + functionspath + "calib_stim.py")
                    elif self.curr_menu_idx == 2:
                        eng.feedback_sig(nargout=0)
                        time.sleep(5)
                        os.system(main_path + functionspath + "SS_Game_BCI.py")
                else:
                    print(scripts_[self.curr_menu_idx])
                    subprocess.Popen(scripts_[self.curr_menu_idx], shell=True, stdout=subprocess.PIPE)
        return self.curr_menu_idx, self.update_menu, self.done

# set debug mode by default
debug_mode(True)

# setup scripts
scripts_=[]
scripts_.append('sh '+main_path+functionspath+'run_eegviewer.sh '+MATLABtootpath+' '+main_path+functionspath+'sigViewer_wrapper.m &')
scripts_.append('sh '+main_path+functionspath+'run_calibration.sh '+MATLABtootpath+' '+main_path+functionspath+'calib_sig.m '+Pythontootpath+' '+main_path+functionspath+'calib_stim.py &')
# scripts_.append('sh '+main_path+functionspath+'run_game.sh '+MATLABtootpath+' '+main_path+functionspath+'feedback_sig.m '+Pythontootpath+' '+main_path+functionspath+'brainflyTest.py 0 &')

# Stevens's
scripts_.append('sh '+main_path+functionspath+'run_game.sh '+MATLABtootpath+' '+main_path+functionspath+'feedback_sig.m '+Pythontootpath+' '+main_path+functionspath+'SS_Game_BCI.py 0 &')

# load assets
winsize=[800,600]
background_img=Image.open(main_path+assetpath+os.sep+"GUI_background.png")
icons=[]
icons.append(Image.open(main_path+assetpath+os.sep+"EEG_off_icon.png"))
icons.append(Image.open(main_path+assetpath+os.sep+"EEG_on_icon.png"))
icons.append(Image.open(main_path+assetpath+os.sep+"set_False_icon.png"))
icons.append(Image.open(main_path+assetpath+os.sep+"set_True_icon.png"))
icons.append(Image.open(main_path+assetpath+os.sep+"keyboard_icon.png"))

# setup GUI
mywin=visual.Window([800,600],units='pix',monitor='testMonitor',winType="pygame")

# background
BG_=visual.ImageStim(mywin,image=background_img)
BG_.setAutoDraw(True)

# EEG indicator
EEG_indicator=visual.ImageStim(mywin,image=icons[0],pos=[-300,250],units='pix')
EEG_indicator.setAutoDraw(True)
EEG_indicator_text=visual.TextStim(mywin,text='EEG mode',font='Futura',pos=[-300,210],units='pix',height=30)
EEG_indicator_text.setAutoDraw(True)

# Keyboard indicator
Keyboard_=visual.ImageStim(mywin,image=icons[4],pos=[-300,-250])
Keyboard_.setAutoDraw(True)
Keyboard_indicator=visual.ImageStim(mywin,image=icons[3],pos=[-200,-250])
Keyboard_indicator.setAutoDraw(True)

# main menu
main_menu=[]
main_menu.append(visual.TextStim(mywin,text='EEG Viewer',font='Helvetica',pos=[0,-50],units='pix',height=36))
main_menu[0].setAutoDraw(True)

main_menu.append(visual.TextStim(mywin,text='Calibration',font='Helvetica',pos=[0,-100],units='pix',height=36))
main_menu[1].setAutoDraw(True)

main_menu.append(visual.TextStim(mywin,text='Play Game',font='Helvetica',pos=[0,-150],units='pix',height=48))
main_menu[2].setAutoDraw(True)

main_menu.append(visual.TextStim(mywin,text='exit',font='Helvetica',pos=[0,-200],units='pix',height=36))
main_menu[3].setAutoDraw(True)

main_menu.append(visual.Line(mywin, start=((main_menu[2].pos[0]-main_menu[2].width/2),(main_menu[2].pos[1]-main_menu[2].height/2)),
                          end=((main_menu[2].pos[0]+main_menu[2].width/2), (main_menu[2].pos[1]-main_menu[2].height/2)),units='pix'))
main_menu[4].setAutoDraw(True)

pygame.mixer.pre_init(44100, 16, 2, 4096)
pygame.mixer.init(44100, -16,2,2048)

pygame.mixer.music.load(main_path+assetpath+os.sep+'backgroundmusic.wav')
pygame.mixer.music.set_volume(1)
pygame.mixer.music.play(-1)

# run GUI
get_keys=keylistener_()
done=False
while not done:
    ev_=event.getKeys()
    curr_menu_idx,update_menu,done=get_keys(ev_)
    if update_menu:
        main_menu[4].start=((main_menu[curr_menu_idx].pos[0]-main_menu[curr_menu_idx].width/2),(main_menu[curr_menu_idx].pos[1]-main_menu[curr_menu_idx].height/2))
        main_menu[4].end=((main_menu[curr_menu_idx].pos[0]+main_menu[curr_menu_idx].width/2),(main_menu[curr_menu_idx].pos[1]-main_menu[curr_menu_idx].height/2))
        mywin.flip()
        update_menu=0
