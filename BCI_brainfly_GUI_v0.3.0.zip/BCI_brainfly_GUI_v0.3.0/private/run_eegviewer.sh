#!/bin/bash
$1/bin/matlab -nosplash -nodesktop -r "run('$2')" &


