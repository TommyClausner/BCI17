cp ../../../../java/*.jar .
cp ../../../../../../java/sigProc/build/jar/*.jar .
