These directories contain basic ft_buffer client code for various platforms and programming languages.
For more information on the fieldtrip buffer protocol see <fieldtrip.donders.ru.nl/development/realtime>.
The code itself has been copied from the fieldtrip repository.

c - [buffer_c](http://fieldtrip.fcdonders.nl/development/realtime/buffer_c)
java - 
 BufferClient code based on [buffer_java](http://fieldtrip.fcdonders.nl/development/realtime/buffer_java)
 BufferServer code *internally developed*
android - BufferServer based on the java BufferServer code
python - [buffer_python](http://fieldtrip.fcdonders.nl/development/realtime/buffer_python)
csharp - *internally developed*
