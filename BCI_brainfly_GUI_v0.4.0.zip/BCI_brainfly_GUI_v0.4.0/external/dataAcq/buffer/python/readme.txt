FieldTrip client implementation in pure Python.
(C) 2010 S. Klanke

Just copy FieldTrip.py to your Python installation's site-package directory, 
or to another PYTHONPATH-included directory of your choice.