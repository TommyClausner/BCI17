In order to use the GUI define your matlab and python instances in the config.txt
The GUI will call this file and looking for MATLABroot and Pythonroot. Both have to be defined in a way that some could plug in a script right behind the root and it would run.

Example (Unix case):
MATLABroot = ~/path_to_MATLAB/bin/matlab -nosplash -nodesktop -r
Pythonroot = ~/path_to_iPython/ipython

The GUI internally would interpret the above commands as follows:
~/path_to_MATLAB/bin/matlab -nosplash -nodesktop -r "try;run('myscript.m');end"
~/path_to_iPython/ipython myscript.py

Example (Windows case):
MATLABroot = C:\path_to_MATLAB\matlab.exe -nosplash -nodesktop -r
Pythonroot = C:\path_to_MATLAB\python.exe

The GUI internally would interpret the above commands as follows:
C:\path_to_MATLAB\matlab.exe -nosplash -nodesktop -r "try;run('myscript.m');end"
C:\path_to_MATLAB\python.exe myscript.py

Note that the relative paths to the respective scripts are set internally.

Commands:
- Switch keyboard mode using 'k'
- Switch EEG mode using 'e'
- Switch music on/off using 'm'
- Switch game mode using 'g'
- use arrow keys to navigate 'up' and 'down'
- hit 'return' to select
- during the calibration hit 'esc' to exit
- during the game hit 'esc' (basic version) or close window (Steven's version) to exit

When Keyboard mode is selected, the feedback_sig.m will not be called. Hence the game window opens much faster.

Further exit commands were added at the end of each MATLAB script to kill the respective instance. When doing the calibration, the exit command will be sent after closing the figure windows.

Aborting the calibration (hitting 'esc') will cause the classifier to be trained on all available data so far.